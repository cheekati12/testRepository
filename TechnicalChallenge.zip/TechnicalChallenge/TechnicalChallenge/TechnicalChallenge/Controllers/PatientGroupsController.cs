﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TechnicalChallenge.Models;

namespace TechnicalChallenge.Controllers
{
    [ApiController]
    public class PatientGroupsController : ControllerBase
    {
        [Route("api/patient-groups/GetGroupsCount")]
        public async Task<PatientGroupsCalculateResponse> GetGroupsCount(PatientGroupsCalculateRequest MatrixList)
        {
            int matrixlength= MatrixList.Matrix.Count;
            int matrixwidth = MatrixList.Matrix.FirstOrDefault().Count;
            int[,] matrix=new int[matrixlength,matrixwidth];
            int m=0, n = 0;
            //converting inputlist of list integers into int[,]
            foreach (List<int> row in MatrixList.Matrix)
            {
                foreach (var col in row)
                {
                    matrix[m,n] = col;
                    n++;
                }
                m++;
                n = 0;
            }
            int groupsCount = 0;
            //traversing through each element of the matrix and converting all 1's intos 0
            for (int i = 0; i < matrixlength; i++)
            {
                for (int j = 0; j < matrixwidth; j++)
                {
                    if (matrix[i, j] == 1)
                    {
                        matrix[i, j] = 0;
                        groupsCount++;
                        SetAdjacentElementValue(i, j, j + 1,matrixlength,matrixwidth,ref matrix);
                    }
                }
            }
            PatientGroupsCalculateResponse response = new PatientGroupsCalculateResponse();
            response.NumberOfGroups = groupsCount;

            return response;
        }
        //using recursive logic to convert the matrix values to 0
        public static void SetAdjacentElementValue(int i, int j, int k,int length,int width, ref int[,] matrix)
        {
            if (j - 1 > 0 && i < length && matrix[i, j - 1] == 1)
            {
                matrix[i, j - 1] = 0;
                SetAdjacentElementValue(i, j - 1, j,length,width, ref matrix);
            }
            if (k < width && i < length && matrix[i, k] == 1)
            {
                matrix[i, k] = 0;
                SetAdjacentElementValue(i, j, k + 1, length, width, ref matrix);
            }
            if (i + 1 < length && j - 1 >= 0 && matrix[i + 1, j - 1] == 1)
            {
                matrix[i + 1, j - 1] = 0;
                SetAdjacentElementValue(i + 1, j, j + 1, length, width, ref matrix);
            }
            if (i + 1 < length && j < width && matrix[i + 1, j] == 1)
            {
                matrix[i + 1, j] = 0;
                SetAdjacentElementValue(i + 2, j, j + 1, length, width, ref matrix);

            }
            if (i + 1 < length && j + 1 < width && matrix[i + 1, j + 1] == 1)
            {
                matrix[i + 1, j + 1] = 0;
                SetAdjacentElementValue(i + 1, j + 1, j + 2, length, width, ref matrix);
            }
        }
    }
}
