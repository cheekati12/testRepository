﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TechnicalChallenge.Models
{
    public class PatientGroupsCalculateResponse
    {
        public int NumberOfGroups { get; set; }
    }
}
