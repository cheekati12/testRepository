﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TechnicalChallenge.Models
{
    public class PatientGroupsCalculateRequest
    {
        public List<List<int>> Matrix { get; set; }
    }
}
